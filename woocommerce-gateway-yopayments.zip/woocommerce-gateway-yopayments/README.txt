The documentation is yet in the pipe line but you can find a quick set up
instructions below:
1. To use the plugin, you have to ensure that you already installed
Woo-Commerce plugin into your existing Word press site.

2. Installation is easy, simply login to your Word press admin portal, go
to plugin section and click Add New button. Choose to upload the plugin zip
file attached to this email.

3. After installation, now move to Setting section of the Woo-Commerce and
then click on the Checkout tab. Scroll down to Payment Gateways. You should
see Yo! Payments added to the list of these gateways.

4. Click on Yo! Payments gateway so you can be taken to the settings page,
see screenshot attached.

5. You should by now have a Yo! Payments business account already, if not,
contact your accounts manager to assist you in obtaining one.

6. Depending on the kind of integration you want, Yo! Payments can avail
various accounts on different systems. That is to say the public (main)
system and the Pay1 system . The public system processes payment that are
hosted at Yo! Uganda (in this case you liquidate your money from Yo
Uganda), well as Pay1 System handles payments where you obtained a
collections account with the networks (MTN and/or Airtel), for which your
payments are hosted at the network (you liquidate your money from the
network). That said, depending on which account and on which system that
account is held, you can configure the Yo! Payments Woo-Commerce setting as
below:
6.1. API Username & password: These should be obtained from the public
system: https://payments.yo.co.ug/ybs/portal
6.2. Pay1 API Username & Password: These should be obtained from the pay1
system: https://pay1.yo.co.ug/ybs/portal. Usually this account is created
by one of Yo! Uganda staff and the credentials are shared with your staff
after your collection account has been mapped at the network. If you don't
have this account yet, you may leave these fields blank.
6.3. Test API Username & Password: Obtain these from the Sandbox system at
http://41.220.12.206/services/yopaymentsdev/portal/index.php. If you don't
have a sandbox account, sign up a free business Sandbox account here:
https://41.220.12.206/services/yopaymentsdev/signup/start/?sid=1

6.4. If you want your WooCommerce to point to your Sandbox account, check
the "Use Test System" checkbox, otherwise it will point to the production
systems.

6.5 If you want your MTN payments to be processed by Pay1 system and given
you already have a Pay1 system which was mapped to your MTN Collection
account, then check Use Pay1 for